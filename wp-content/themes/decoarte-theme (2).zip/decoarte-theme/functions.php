<?php
/**
 * Funciones principales del tema Decoarte
 * 
 * @package Decoarte
 */

// Evitar acceso directo
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Cargar estilos y scripts del tema
 */
function decoarte_enqueue_assets() {
    // Cargar el archivo style.css (obligatorio en WordPress)
    // Este archivo debe contener el encabezado del tema + todo el CSS
    wp_enqueue_style(
        'decoarte-style',
        get_stylesheet_uri(), // Apunta automáticamente a style.css en la raíz del tema
        array(),              // Sin dependencias
        filemtime( get_stylesheet_directory() . '/style.css' ) // Versión = última modificación
    );
}

// Acción para cargar estilos en el frontend
add_action( 'wp_enqueue_scripts', 'decoarte_enqueue_assets' );