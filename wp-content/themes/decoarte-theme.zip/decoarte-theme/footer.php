<?php
?>
<footer class="site-footer">
    <p>&copy; <?php echo date('Y'); ?> DecoArte Spa</p>
</footer>
<?php wp_footer(); ?>
</body>
</html>