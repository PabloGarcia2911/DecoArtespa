<?php
/**
 * Funciones principales del tema DecoArte
 */

function decoarte_enqueue_styles() {
    // Estilo principal del tema (style.css)
    wp_enqueue_style('main-style', get_stylesheet_uri());

    // Archivos CSS personalizados del tema
    $css_files = array('variables', 'base', 'header', 'hero', 'products', 'about', 'footer', 'responsive');
    foreach ($css_files as $file) {
        $path = get_stylesheet_directory_uri() . '/assets/css/' . $file . '.css';
        wp_enqueue_style(
            'decoarte-' . $file,
            $path,
            array('main-style'),
            filemtime(get_stylesheet_directory() . '/assets/css/' . $file . '.css') // cache-busting
        );
    }

    // Font Awesome desde CDN
    wp_enqueue_style(
        'font-awesome',
        'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css',
        array(),
        '6.0.0'
    );
}
add_action('wp_enqueue_scripts', 'decoarte_enqueue_styles');

/**
 * Habilitar soporte de características de WordPress
 */
function decoarte_theme_setup() {
    // Soporte para imágenes destacadas
    add_theme_support('post-thumbnails');

    // Soporte para título dinámico en <title>
    add_theme_support('title-tag');

    // Registrar menús de navegación
    register_nav_menus(array(
        'primary'   => __('Menú Principal', 'decoarte'),
        'footer'    => __('Menú Footer', 'decoarte'),
    ));
}
add_action('after_setup_theme', 'decoarte_theme_setup');

/**
 * Registrar área de widgets
 */
function decoarte_widgets_init() {
    register_sidebar(array(
        'name'          => __('Sidebar Principal', 'decoarte'),
        'id'            => 'sidebar-1',
        'description'   => __('Widgets que aparecerán en la barra lateral.', 'decoarte'),
        'before_widget' => '<section class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
}
add_action('widgets_init', 'decoarte_widgets_init');
